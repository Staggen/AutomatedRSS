﻿namespace OurPodcastApp {
    public interface ITitleable {
        string Title { get; set; }
    }
}