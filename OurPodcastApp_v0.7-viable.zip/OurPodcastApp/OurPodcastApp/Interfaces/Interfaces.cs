﻿namespace OurPodcastApp {
    public interface ITitleicious {
        string Title { get; set; }
    }
}