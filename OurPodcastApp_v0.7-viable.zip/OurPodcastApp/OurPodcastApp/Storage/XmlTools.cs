﻿using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using System.Xml;

namespace OurPodcastApp {
    public class XmlTools {
        public static XmlDocument GetXmlDocument(string url) {
            XmlDocument myDocument = new XmlDocument();
            myDocument.Load(url);
            return myDocument;
        }

        public static string SaveFeedToFile(string url, string feedTitle) {
            string legalTitle = Regex.Replace(feedTitle, @"[/:*|\\<>?]+", ""); // Rename the title to something that only contains characters which are legal in the windows file system
            string filePath = Workfolders.GetFolder(Workfolders.Folders.SavePodData) + legalTitle + ".xml";
            if (File.Exists(filePath)) { // If the file already exists, we have to remove it to "update" it.
                File.Delete(filePath);
            }
            XmlDocument document = new XmlDocument(); // Holding variable
            document.Load(url); // Load the rss file into the holding variable
            document.Save(filePath); // Save the rss file to a local xml document for later use
            return filePath;
        }

        public static Dictionary<string, string> GetEpisodeInfo(string path) {
            Dictionary<string, string> episodeDictionary = new Dictionary<string, string>(); // Make dictionary
            string fixedDescription;
            XmlDocument document = new XmlDocument(); // Holding variable
            document.Load(path); // Load the XML document into the holding variable
            XmlNodeList titles = document.SelectNodes("//rss/channel/item/title"); // List of XML nodes matching selector
            XmlNodeList descriptions = document.SelectNodes("//rss/channel/item/description"); // --||--
            for (int i = 0; i < titles.Count; i++) { // titles and descriptions SHOULD be equally long
                fixedDescription = Regex.Replace(descriptions[i].InnerText,@"<.*?>",""); // Remove HTML formating
                episodeDictionary.Add(titles[i].InnerText, fixedDescription); // Add titles and descriptions to the dictionary
            }
            return episodeDictionary; // Return dictionary
        }
    }
}