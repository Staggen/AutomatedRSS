﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Xml;

namespace OurPodcastApp {
    public class Feed : ITitleicious {
        public string Title { get; set; }
        public int EpisodeCount { get; set; }
        public string UpdateFrequency { get; set; }
        public string Genre { get; set; }
        public DateTime LatestCheckUpdated { get; set; }

        public static string FeedFilePath = Workfiles.GetFile(Workfiles.Files.FeedFile);

        public static string[] GenerateNewFeed(string feedUrl, string updateFreq, string genre) { // Finished
            XmlDocument myRSSFeed = XmlTools.GetXmlDocument(feedUrl); // !WebRequest! GetXmlDocument returns a xml document loaded with whatever was returned from the URL passed into the method
            string feedTitle = myRSSFeed.SelectSingleNode("//rss/channel/title").InnerText; // Get title
            string filePath = XmlTools.SaveFeedToFile(feedUrl, feedTitle); // Saves the RSS feed to a local xml file
            int episodeCount = GetEpisodeCount(filePath); // Get episode count
            return new string[] { episodeCount.ToString(), feedTitle, updateFreq, genre, feedUrl, DateTime.Now.ToUniversalTime().ToString() };
        }

        public static void DeleteFeedItem(ListView lv) { // Finished
            foreach (ListViewItem item in lv.SelectedItems) { // Remove the selected item from the list view
                lv.Items.Remove(item);
            }
        }

        public static void UpdateFeedItemFreq(ListView lv, string newValue) { // Finished
            lv.SelectedItems[0].SubItems[2].Text = newValue;
        }

        public static void UpdateFeedItemGenre(ListView lv, string newValue) { // Finished
            lv.SelectedItems[0].SubItems[3].Text = newValue;
        }

        public static void UpdateFeedFile(ListView lv) { // Finished
            var feedPath = Workfiles.GetFile(Workfiles.Files.FeedFile);
            ListViewItem[] currentFeeds = new ListViewItem[lv.Items.Count];
            lv.Items.CopyTo(currentFeeds, 0);
            foreach (var item in currentFeeds) {
                var tempList = new string[item.SubItems.Count];
                for (int i = 0; i < tempList.Length; i++) {
                    tempList[i] = item.SubItems[i].Text;
                }
                Serializer.Serialize(feedPath, Serializer.SerializeList(tempList));
            }
        }

        public static int GetEpisodeCount(string path) { // Finished
            return XmlTools.GetEpisodeInfo(path).Count; // Can be both local and external path (web request)
        }

        public static void UpdateFeedItemEpCount(Dictionary<int, bool> data, ListView view) { // Finished
            foreach (var kvp in data) {
                MessageBox.Show(view.Items[kvp.Key].SubItems[5].Text); // REMOVE BEFORE HANDING IN
                if (kvp.Value == false) {
                    // Gets a fresh episode count from the url tied to the current feed item.
                    int newEpCount = GetEpisodeCount(view.Items[kvp.Key].SubItems[4].Text);
                    // Updates the episodes count in the list
                    view.Items[kvp.Key].SubItems[0].Text = newEpCount.ToString();
                    // Updates the timestamp to current time
                    view.Items[kvp.Key].SubItems[5].Text = DateTime.Now.ToUniversalTime().ToString();
                }
            }
        }

        public static EpisodeList GetEpisodes(string feedTitle) { // Finished
            EpisodeList episodeList = new EpisodeList();
            string legalTitle = Regex.Replace(feedTitle, @"[/:*|\\<>?]+", ""); // Modify the feedTitle to a filesystem-legal title. We remove all the characters that are not allowed in file names.
            string feedPath = Workfolders.GetFolder(Workfolders.Folders.SavePodData)+legalTitle+".xml";
            int numberOfEpisodes = GetEpisodeCount(feedPath); // Gets the number of episodes in a specific feed
            string[] myKeys = new string[numberOfEpisodes];
            string[] myValues = new string[numberOfEpisodes];
            Dictionary<string, string> episodeDictionary = XmlTools.GetEpisodeInfo(feedPath); // Get a dictionary filled with all the episode titles and corresponding descriptions.
            episodeDictionary.Keys.CopyTo(myKeys, 0); // Required to access the keys by position
            episodeDictionary.Values.CopyTo(myValues, 0); // Required to access the values by position
            for (int i = 0; i < numberOfEpisodes; i++) {
                episodeList.Add(new Episode { Title = myKeys[i], Description = myValues[i] }); // Making new objects of Episode containing the Title and Description of episodes
            }
            return episodeList;
        }

        public class FeedList : List<Feed> { // Remake feeds into lists of feed, so we can use the objects rather than just the string arrays we currently use. Fix when the rest works I guess?
            FeedList() {
                // Constructors'R'Us
            }
        }
    }
}