﻿using System.IO;

namespace OurPodcastApp {
    public class Frequencies {
        public static string FreqPath = Workfiles.GetFile(Workfiles.Files.FreqFile);
        
        public static string[] freqList = {
            "Ten min",
            "One hour",
            "One day",
            "One week",
            "One month"
        };

        public enum Frequency {
            min,
            hr,
            day,
            week,
            month,
        }

        public static string GetFreq(Frequency name) {
            return freqList[(int)name];
        }

        public static void CreateFreqs() {
            if (!File.Exists(FreqPath)) {
                Serializer.Serialize(FreqPath, freqList);
            } else {
                Workfiles.ClearFile(FreqPath);
                Serializer.Serialize(FreqPath, freqList);
            }
        }

        public static string[] ReadFrequencies() {
            return Serializer.Deserialize(FreqPath);
        }
    }
}