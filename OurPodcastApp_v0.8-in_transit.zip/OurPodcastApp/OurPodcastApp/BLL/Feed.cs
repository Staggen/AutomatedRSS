﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace OurPodcastApp {
    public class Feed : ITitleicious {
        public int EpisodeCount { get; set; }
        public string Title { get; set; }
        public string UpdateFrequency { get; set; }
        public string Genre { get; set; }
        public string FeedURL { get; set; }
        public DateTime LastCheckForUpdates { get; set; }

        public Feed() {
            // Constructors'R'Us
        }

        public static string FeedFilePath = Workfiles.GetFile(Workfiles.Files.FeedFile);

        public static List<ListViewItem> GetAllFeedsFromFile() {
            return Serializer.DeserializeList(Serializer.Deserialize(Workfiles.GetFile(Workfiles.Files.FeedFile)));
        }

        public static void DeleteFeedItem(ListView lv) {
            foreach (ListViewItem item in lv.SelectedItems) { // Remove the selected item from the list view
                lv.Items.Remove(item);
            }
        }

        public static void UpdateFeedItemFreq(ListView lv, string newValue) {
            lv.SelectedItems[0].SubItems[2].Text = newValue;
        }

        public static void UpdateFeedItemGenre(ListView lv, string newValue) {
            lv.SelectedItems[0].SubItems[3].Text = newValue;
        }

        public static void UpdateFeedFile(ListView lv) {
            var feedPath = Workfiles.GetFile(Workfiles.Files.FeedFile);
            ListViewItem[] currentFeeds = new ListViewItem[lv.Items.Count];
            lv.Items.CopyTo(currentFeeds, 0);
            foreach (var item in currentFeeds) {
                var tempList = new string[item.SubItems.Count];
                for (int i = 0; i < tempList.Length; i++) {
                    tempList[i] = item.SubItems[i].Text;
                }
                Serializer.Serialize(feedPath, Serializer.SerializeList(tempList));
            }
        }


        public static void UpdateByUrls(ListViewItem fresh, ListViewItem old) {
            var oldUrl = old.SubItems[4].Text;
            var newUrl = fresh.SubItems[4].Text;
            if (old.SubItems[2].Text != fresh.SubItems[2].Text) {
                if (newUrl == oldUrl) {
                    UpdateFeedEntryFrequency(fresh, old);
                }
                if (old.SubItems[3].Text != fresh.SubItems[3].Text) {
                    if (newUrl == oldUrl) {
                        UpdateFeedEntryGenre(fresh, old);
                    }
                }
            }
        }
        public static void UpdateFeedEntryGenre(ListViewItem fresh, ListViewItem old) {
            old.SubItems[3].Text = fresh.SubItems[3].Text;
        }
        public static void UpdateFeedEntryFrequency(ListViewItem fresh, ListViewItem old) {
            old.SubItems[2].Text = fresh.SubItems[2].Text;
        }

        public static void UpdateFeedFileCheckFreqAndGen(ListView lv) {
            //get the complete filepath to the feed file.
            string feedPath = Workfiles.GetFile(Workfiles.Files.FeedFile);
            //deserialize ALL the feeds previously serialized.
            List<ListViewItem> allFeeds = Serializer.DeserializeList(Serializer.Deserialize(Workfiles.GetFile(Workfiles.Files.FeedFile)));
            //prepare an array of listviewitems that will hold the currently displaying items.
            ListViewItem[] currentFeeds = new ListViewItem[lv.Items.Count];
            lv.Items.CopyTo(currentFeeds, 0); //get the current, possibly filtered items, with possibly new values for update frequency and/or genre, and copy to the previously declared array.
            
            //initialize brain-churning.
            foreach (ListViewItem allFeedFeed in allFeeds) {
                //(for)each feed in ALL OF THE FEEDS (!!!)... will be checked against...
                foreach (ListViewItem currentFeed in currentFeeds) {
                    //...EACH (!!!) of ALL currently displaying feeds.
                    string oldUrl = currentFeed.SubItems[4].Text;
                    //urls are in this case a uniqque identifier, so lets get them from ALL FEED ITEMS (!!!) ... total ... in both lists
                    string newUrl = allFeedFeed.SubItems[4].Text;
                    //if the urls match that means we have two items destined for love...
                    if (newUrl == oldUrl) {
                        //...and then, naturally, if something isn't exactly as she sees it best...
                        if(currentFeed.SubItems[2].Text != allFeedFeed.SubItems[2].Text || currentFeed.SubItems[3].Text != allFeedFeed.SubItems[3].Text) {
                            //...she enforces her will...
                            allFeedFeed.SubItems[2].Text = currentFeed.SubItems[2].Text;
                            allFeedFeed.SubItems[3].Text = currentFeed.SubItems[3].Text;
                        }
                    }
                }
            }
            //...brainwashes the other one and then fucks off either way.
            Workfiles.ClearFile(feedPath);

            foreach (ListViewItem item in allFeeds) {
                string[] tempList = new string[item.SubItems.Count];
                for (int i = 0; i < tempList.Length; i++) {
                    tempList[i] = item.SubItems[i].Text;
                }
                Serializer.Serialize(feedPath, Serializer.SerializeList(tempList));
            }
        }

        public static void ResetGenresFilter(ListView lv) {
            List<ListViewItem> feedByGen = new List<ListViewItem>();
            List<ListViewItem> checkFeeds = Serializer.DeserializeList(Serializer.Deserialize(Workfiles.GetFile(Workfiles.Files.FeedFile)));
            lv.Items.Clear();
            Populate.updateListView(lv, checkFeeds);
        }
    }

    public class FeedList : List<Feed> { // IMPLEMENT!
        public FeedList() {
            // Constructors'R'Us
        }
    }
}