﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace OurPodcastApp {
    public class Updater {
        public static List<ListViewItem> ListLooper(ListView view) {
            List<ListViewItem> allFeedEntries = new List<ListViewItem>();
            foreach (ListViewItem item in view.Items) {
                allFeedEntries.Add(item);
            }
            return allFeedEntries;
        }

        public static Dictionary<int, bool> CheckForUpdates(List<ListViewItem> list) {
            Dictionary<int, bool> updates = new Dictionary<int, bool>();
            foreach (ListViewItem item in list) {
                updates.Add(item.Index, CompareTimestamps(item));
            }
            return updates;
        }

        public static bool CompareTimestamps(ListViewItem item) {
            switch (item.SubItems[2].Text) {
                case "Ten minutes":
                    return DateTime.Parse(item.SubItems[5].Text).AddMinutes(10) > DateTime.Now.ToUniversalTime();
                case "One hour":
                    return DateTime.Parse(item.SubItems[5].Text).AddHours(1) > DateTime.Now.ToUniversalTime();
                case "One day":
                    return DateTime.Parse(item.SubItems[5].Text).AddDays(1) > DateTime.Now.ToUniversalTime();
                case "One week":
                    return DateTime.Parse(item.SubItems[5].Text).AddDays(7) > DateTime.Now.ToUniversalTime();
                case "One month":
                    return DateTime.Parse(item.SubItems[5].Text).AddMonths(1) > DateTime.Now.ToUniversalTime();
                default:
                    return true;
            }
        }
    }
}