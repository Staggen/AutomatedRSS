﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Xml;

namespace OurPodcastApp {
    class EntityLogicLayer {
        private static FeedList PersistentFeedList = new FeedList();
        private static FeedList FilteredFeedList = new FeedList();
        private static FeedList TempFeedList = new FeedList();

        EntityLogicLayer() { // Might need to move instantiation of lists to the constructor and call it in Form1 on load?
            // Constructors'R'Us
        }

        public static void SaveToPersistent(FeedList feedList) {
            PersistentFeedList = feedList;
        }

        public static FeedList BuildTempFeedList(ListView listView) {
            FeedList feedList = new FeedList();
            foreach (ListViewItem item in listView.Items) { // Re-write the list to the list view passed in as a parameter
                if (Int32.TryParse(item.SubItems[0].Text, out int tempCount) && DateTime.TryParse(item.SubItems[5].Text, out DateTime tempDate)) { // Try to convert string to int, and string to DateTime
                    feedList.Add(new Feed { // Add a feed to the list of feeds
                        EpisodeCount = tempCount,
                        Title = item.SubItems[1].Text,
                        UpdateFrequency = item.SubItems[2].Text,
                        Genre = item.SubItems[3].Text,
                        FeedURL = item.SubItems[4].Text,
                        LastCheckForUpdates = tempDate
                    });
                }
            }
            return feedList;
        }

        public static List<ListViewItem> PersistentFeedListToLvMain() {
            List<ListViewItem> list = new List<ListViewItem>();
            foreach (Feed item in PersistentFeedList) {
                ListViewItem listItem = Converter.FeedToLVI(item);
                list.Add(listItem);
            }
            return list;
        }

        public static List<ListViewItem> FilteredFeedListToLvMain() {
            List<ListViewItem> list = new List<ListViewItem>();
            foreach (Feed item in FilteredFeedList) {
                ListViewItem listItem = Converter.FeedToLVI(item);
                list.Add(listItem);
            }
            return list;
        }

        public static void SetPersistentFeedListToSaveFile() { // Save the persistent feed list to the feed file
            string[] entireFeed = new string[PersistentFeedList.Count]; // Holding array for the entire feed
            for (int i = 0; i < PersistentFeedList.Count; i++) {
                string[] singleItem = Converter.FeedToSA(PersistentFeedList[i]); // Run through the items in the list of feeds
                string serializedItem = Serializer.SerializeList(singleItem); // Write the individual ListViewItem string arrays into a single serialized item
                entireFeed[i] = serializedItem; // Add the item to the holding array
            }
            Workfiles.ClearFile(Workfiles.GetFile(Workfiles.Files.FeedFile)); // Clear the FeedFile
            Serializer.Serialize(Workfiles.GetFile(Workfiles.Files.FeedFile), entireFeed); // Write entireFeed to the feed file
        }

        public static void GetPersistentFeedListFromSaveFile() {
            string[] singleItem = Serializer.Deserialize(Workfiles.GetFile(Workfiles.Files.FeedFile));
            List<ListViewItem> listItems = Serializer.DeserializeList(singleItem); // Deserialize the feed file (where we save the things that are to be put into the list view items)
            PersistentFeedList.Clear();
            foreach (ListViewItem item in listItems) {
                Feed feedItem = Converter.LVIToFeed(item);
                PersistentFeedList.Add(feedItem);
            }
        }

        public static int GetEpisodeCount(string path) {
            return XmlTools.GetEpisodeInfo(path).Count; // Can be both local and external path (web request)
        }

        public static EpisodeList GetEpisodes(string feedTitle) {
            EpisodeList episodeList = new EpisodeList();
            string legalTitle = Regex.Replace(feedTitle, @"[/:*|\\<>?]+", ""); // Modify the feedTitle to a filesystem-legal title. We remove all the characters that are not allowed in file names.
            string feedPath = Workfolders.GetFolder(Workfolders.Folders.SavePodData) + legalTitle + ".xml";
            int numberOfEpisodes = GetEpisodeCount(feedPath); // Gets the number of episodes in a specific feed
            string[] myKeys = new string[numberOfEpisodes];
            string[] myValues = new string[numberOfEpisodes];
            Dictionary<string, string> episodeDictionary = XmlTools.GetEpisodeInfo(feedPath); // Get a dictionary filled with all the episode titles and corresponding descriptions.
            episodeDictionary.Keys.CopyTo(myKeys, 0); // Required to access the keys by position
            episodeDictionary.Values.CopyTo(myValues, 0); // Required to access the values by position
            for (int i = 0; i < numberOfEpisodes; i++) {
                episodeList.Add(new Episode { Title = myKeys[i], Description = myValues[i] }); // Making new objects of Episode containing the Title and Description of episodes
            }
            return episodeList;
        }

        public static Feed GenerateNewFeed(string feedURL, string updateFrequency, string genre) {
            XmlDocument myRSSFeed = XmlTools.GetXmlDocument(feedURL); // !WebRequest! GetXmlDocument returns a xml document loaded with whatever was returned from the URL passed into the method
            string feedTitle = myRSSFeed.SelectSingleNode("//rss/channel/title").InnerText; // Get feedTitle
            XmlTools.SaveFeedToFile(feedURL, feedTitle); // Saves the RSS feed to a local xml file
            string filePath = XmlTools.GetFeedXmlFilePath(feedTitle);
            return new Feed { // Return a new Feed object
                EpisodeCount = GetEpisodeCount(filePath),
                Title = feedTitle,
                UpdateFrequency = updateFrequency,
                Genre = genre,
                FeedURL = feedURL,
                LastCheckForUpdates = DateTime.Now.ToUniversalTime()
            };
        }

        public static string[] GenerateNewFeedSA(string feedURL, string updateFrequency, string genre) {
            Feed newFeed = GenerateNewFeed(feedURL, updateFrequency, genre);
            return new string[] { // Make a string array so we can create the ListViewItem
                newFeed.EpisodeCount.ToString(),
                newFeed.Title,
                newFeed.UpdateFrequency,
                newFeed.Genre,
                newFeed.FeedURL,
                newFeed.LastCheckForUpdates.ToString()
            };
        }

        public static ListViewItem GenerateNewFeedLVI(string feedURL, string updateFrequency, string genre) {
            Feed newFeed = GenerateNewFeed(feedURL, updateFrequency, genre);
            string[] newFeedStringArray = new string[] { // Make a string array so we can create the ListViewItem
                newFeed.EpisodeCount.ToString(),
                newFeed.Title,
                newFeed.UpdateFrequency,
                newFeed.Genre,
                newFeed.FeedURL,
                newFeed.LastCheckForUpdates.ToString()
            };
            return new ListViewItem(newFeedStringArray);
        }

        public static void UpdateFeedItemEpCount(Dictionary<int, bool> data, ListView view) { // Finished
            foreach (var kvp in data) {
                MessageBox.Show(view.Items[kvp.Key].SubItems[5].Text); // REMOVE BEFORE HANDING IN
                if (kvp.Value == false) {
                    // Gets a fresh episode count from the url tied to the current feed item.
                    int newEpCount = GetEpisodeCount(view.Items[kvp.Key].SubItems[4].Text);
                    // Updates the episodes count in the list
                    view.Items[kvp.Key].SubItems[0].Text = newEpCount.ToString();
                    // Updates the timestamp to current time
                    view.Items[kvp.Key].SubItems[5].Text = DateTime.Now.ToUniversalTime().ToString();
                }
            }
        }
    }
}
