﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OurPodcastApp {
    public partial class Form1 : Form {
        // Cancellation Token Source
        CancellationTokenSource cts = new CancellationTokenSource(); // To allow timeouts on asynchronous tasks
        // Constructor
        public Form1() {
            InitializeComponent(); // Generate the visual form
        }
        // Form_Load
        private void Form1_Load(object sender, EventArgs e) {
            // Runs on form load
            Workfiles.CheckOrCreateWorkFiles(); // Check tha the work files exist
            Workfolders.CheckOrCreateWorkspaceFolders(); // Check that the work folders exist
            
            btnNewFeed.Enabled = false; // Disabling all buttons - they will become enabled at appropriate times
            btnSaveFeed.Enabled = false;
            btnDelFeed.Enabled = false;
            btnNewCat.Enabled = false;
            btnSaveCat.Enabled = false;
            btnDelCat.Enabled = false;

            List<ListViewItem> listItems = Serializer.DeserializeList(Serializer.Deserialize(Workfiles.GetFile(Workfiles.Files.FeedFile))); // Deserialize the feed file (where we save the things that are to be put into the list view items)
            foreach (ListViewItem item in listItems) {
                Populate.updateListView(lvMain, item); // Add the items in the feed file to the feed
            }

            lvMain.FullRowSelect = true; // Make the selector cover the full row

            var listOfGenres = Genre.ReadGenres();
            Populate.updateList(lbxGenre, listOfGenres); // Add the list of genres to the list box
            Populate.updateList(cbxGenre, listOfGenres); // Add the list of genres to the combo box
            cbxGenre.Items.RemoveAt(0); // Remove "All Genres" from the combo box
            var listOfFrequencies = Frequencies.ReadFrequencies();
            Populate.updateList(cbxUpFreq, listOfFrequencies); // Add the list of frequencies to the combo box

            // ListLooper returns a List of ListViewItems, which we use to call CheckForUpdates, which
            // returns a Dictionary. Then we use that dictionary as a parameter in UpdateFeed.
            EntityLogicLayer.UpdateFeedItemEpCount(Updater.CheckForUpdates(Updater.ListLooper(lvMain)), lvMain);
            Workfiles.ClearFile(Workfiles.GetFile(Workfiles.Files.FeedFile));
            Feed.UpdateFeedFile(lvMain);
        }
        // Onclick Event(s)
        private void btnNewCat_Click(object sender, EventArgs e) {
            Genre.AddGenre(txtPoseidon.Text); // Add the genre that is in the text field to the list box
            var listOfGenres = Genre.ReadGenres();
            Populate.updateList(lbxGenre, listOfGenres); // Update the contents of the list box
            Populate.updateList(cbxGenre, listOfGenres); // Update the contents of the combo box
            cbxGenre.Items.RemoveAt(0); // Remove the "All Genres" genre from the combo box
            txtPoseidon.Clear(); // Clear the input field
            txtPoseidon.Focus(); // Return focus to the input field
        }

        private void btnNewFeed_Click(object sender, EventArgs e) {
            // Adds a new feed to the ListView by calling the addNewFeed with the list to which the feed 
            // should be added and another method, which returns a ListViewItem with information pulled
            // from the xml-file the url points to.
            if (txtUrl.Text != null && cbxUpFreq.SelectedItem != null && cbxGenre.SelectedItem != null) {
                if (Validation.IsValidURL(txtUrl.Text)) {
                    try {
                        cts.CancelAfter(2500); // Time out (terminate) async operation if it has not completed after 2.5 seconds
                        Task asyncAddingFeed = new Task(() => AddingFeedLVIToListView(cts)); // I MUST make this a new method to be able to pass in a parameter.
                        asyncAddingFeed.Start();
                    } catch (OperationCanceledException) {
                        MessageBox.Show("The web request to add a new feed timed out! (Exceeded 2.5 second response time)");
                    } catch (Exception ex) {
                        MessageBox.Show(ex.Message);
                    }
                } else {
                    MessageBox.Show("Make sure that the URL is correct!");
                }
            } else {
                MessageBox.Show("Make sure you have filled out all fields!");
            }
            Populate.refreshSelection(lbxGenre);
        }
        private void AddingFeedLVIToListView(CancellationTokenSource ct) {
            string feedURL = txtUrl.Text;
            string updateFrequency = cbxUpFreq.SelectedItem.ToString();
            string genre = cbxGenre.SelectedItem.ToString();
            ListViewItem newFeedLVI = EntityLogicLayer.GenerateNewFeedLVI(feedURL, updateFrequency, genre); // New feed in ListViewItem format
            Populate.updateListView(lvMain, newFeedLVI); // Add the new ListViewItem to the main ListView
            string[] newFeedSA = EntityLogicLayer.GenerateNewFeedSA(feedURL, updateFrequency, genre); // New feed in string array format
            string serializedFeed = Serializer.SerializeList(newFeedSA); // Serialize the feed string array into a single string
            Serializer.Serialize(Workfiles.GetFile(Workfiles.Files.FeedFile), serializedFeed); // Write the serialized feed into the feed file
            txtUrl.Clear(); // Clear the textfield where the URL was put in
        }

        private void btnSaveCat_Click(object sender, EventArgs e) {
            if (lbxGenre.SelectedIndex >= 1) { // If category selected is index 1 or higher
                lbxGenre.Items[lbxGenre.SelectedIndex] = txtPoseidon.Text; // Set the currently selected index to match the text field txtPoseidon
            }
            Workfiles.ClearFile(Genre.GetGenrePath()); // Clear the genre file
            Populate.updateList(cbxGenre, Genre.UpdateGenreFile(lbxGenre)); // Update the list box and re-write the genre file to match the new content in the list box
            cbxGenre.Items.RemoveAt(0); // Remove the "All Genres" genre from the combo box
        }

        private void btnSaveFeed_Click(object sender, EventArgs e) {
            Feed.UpdateFeedItemFreq(lvMain, cbxUpFreq.Text); // Update a feed item's update frequency
            Feed.UpdateFeedItemGenre(lvMain, cbxGenre.Text); // Update a feed item's genre               
            Feed.UpdateFeedFileCheckFreqAndGen(lvMain); // Re-write the feed file to represent the newly updated list view
            Populate.refreshSelection(lbxGenre);            
        }

        private void btnDelCat_Click(object sender, EventArgs e) {
            if (lbxGenre.SelectedIndex >= 1) { // If category selected is index 1 or higher
                Genre.DeleteGenre(lbxGenre); // Delete the genre from the list box
                Workfiles.ClearFile(Genre.GetGenrePath()); // Clear the genre file
                Populate.updateList(cbxGenre, Genre.UpdateGenreFile(lbxGenre)); // Update the list box and re-write the genre file to match the new content in the list box
                cbxGenre.Items.RemoveAt(0); // Remove the "All Genres" genre from the combo box
            } else {
                txtPoseidon.Clear(); // Clear the input field
            }
        }

        private void btnDelFeed_Click(object sender, EventArgs e) {
            Feed.DeleteFeedItem(lvMain); // Delete the feed item from the list view
            Workfiles.ClearFile(Workfiles.GetFile(Workfiles.Files.FeedFile)); // Clear the feed file
            Feed.UpdateFeedFile(lvMain); // Re-write the feed file to match the new content in the list view
        }
        // Selection-changed Event(s)
        private void lvlMain_ItemSelectionChanged(object sender, ListViewItemSelectionChangedEventArgs e) {
            if (lvMain.SelectedItems.Count > 0) {
                string url = lvMain.SelectedItems[0].SubItems[4].Text; // Get the URL from the selected list view item
                string feedTitle = lvMain.SelectedItems[0].SubItems[1].Text; // Get the feed title from the selected list view item
                Populate.updateList(lbxEpidsodes, EntityLogicLayer.GetEpisodes(feedTitle)); // Update the Episodes list box for the currently selected list view item, and load the episodes into the list
                lblFeedTitle.Text = feedTitle; // Set the label to the feed title
                txtUrl.Text = url; // Set the input field to match the newly selected item's URL
                cbxUpFreq.SelectedItem = lvMain.SelectedItems[0].SubItems[2].Text; // Set the selected item in the combo box to match the currently selected item in the list view
                cbxGenre.SelectedItem = lvMain.SelectedItems[0].SubItems[3].Text; // Set the selected item in the combo box to match the currently selected item in the list view

                btnSaveFeed.Enabled = true;
                btnDelFeed.Enabled = true;
                txtUrl.Enabled = false;
            } else {
                lbxEpidsodes.Items.Clear(); // Clear the episodes window if nothing is selected in lvMain
                txtDescription.Clear(); // Clear the description window if nothing is selected in lvMain
                btnSaveFeed.Enabled = false;
                btnDelFeed.Enabled = false;
                txtUrl.Enabled = true;
            }
        }

        private void lbxGenre_SelectedIndexChanged(object sender, EventArgs e) {
            // It is important that the text-field modifiers come before the button state modifiers. This is because there are listeners who change the button states upon text-change. This means that if you change the buttons first, and then the text, the listeners will fire and modify the button states to what they say they should be rather than what you want it to be here.
            if (lbxGenre.SelectedIndex >= 1) {
                txtPoseidon.Text = lbxGenre.SelectedItem.ToString();
                btnNewCat.Enabled = false;
                btnSaveCat.Enabled = true;
                btnDelCat.Enabled = true;
                btnSaveFeed.Enabled = false;
            } else if (lbxGenre.SelectedIndex == 0) {
                txtPoseidon.Clear(); // To not allow people to modify the first entry ("All genres").
                btnNewCat.Enabled = false;
                btnSaveCat.Enabled = false;
                btnDelCat.Enabled = false;
                btnSaveFeed.Enabled = true;
            } else {
                txtPoseidon.Clear();
                btnNewCat.Enabled = true;
                btnSaveCat.Enabled = false;
                btnDelCat.Enabled = false;
            }

            List<ListViewItem> feedsByGenre = Genre.FilterFeedByGenre(lbxGenre, lvMain);
            Populate.updateListView(lvMain, feedsByGenre);
        }

        private void lbxEpisodes_SelectedIndexChanged(object sender, EventArgs e) {
            if (lvMain.SelectedItems.Count > 0) {
                // Gets the description of the episode from the stored feed's XML file, and updates the description text box by getting the feed title from the currently selected item in lvMain, then accessing the index of the Episode-List it returns using the index of the selected item in lbxEpisodes, and finally getting the Description field.
                EpisodeList episodes = EntityLogicLayer.GetEpisodes(lvMain.SelectedItems[0].SubItems[1].Text); // Get list of episodes
                int selectedIndex = lbxEpidsodes.SelectedIndex; // Currently selected index
                string description = episodes[selectedIndex].Description; // Get description from currently selected episode
                Populate.updateList(txtDescription, description); // Update the text box txtDescription
            }
        }

        // KeyDown/KeyUp/KeyPress Event(s)
        private void txtUrl_TextChanged(object sender, EventArgs e) {
            btnNewFeed.Enabled = string.IsNullOrWhiteSpace(txtUrl.Text) ? false : true;
        }

        private void txtPoseidon_TextChanged(object sender, EventArgs e) {
            btnNewCat.Enabled = string.IsNullOrWhiteSpace(txtPoseidon.Text) ? false : true;
        }
    }
}