﻿namespace OurPodcastApp {
    public class Entity {
        public virtual string EntityType() {
            return "This is a generic entity.";
        }
    }
}