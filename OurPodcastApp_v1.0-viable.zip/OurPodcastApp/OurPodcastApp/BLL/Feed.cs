﻿using System;
using System.Collections.Generic;

namespace OurPodcastApp {
    public class Bullshit {
        public virtual void WhatIsMyPurpose() {

        }
    }

    public class Feed : Bullshit, ITitleicious {
        public int EpisodeCount { get; set; }
        public string Title { get; set; }
        public string UpdateFrequency { get; set; }
        public string Genre { get; set; }
        public string FeedURL { get; set; }
        public DateTime LastCheckForUpdates { get; set; }
        public EpisodeList Episodes { get; set; }
    }

    public class FeedList : List<Feed> {
        public FeedList() {
            // Constructors'R'Us
        }
    }
}