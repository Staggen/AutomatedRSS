﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OurPodcastApp {
    public partial class Form1 : Form {
        // Cancellation Token Source
        CancellationTokenSource cts = new CancellationTokenSource(); // To allow timeouts on asynchronous tasks
        // Constructor
        public Form1() {
            InitializeComponent(); // Generate the visual form
        }
        // Form_Load
        private void Form1_Load(object sender, EventArgs e) {
            // Runs on form load
            Workfiles.CheckOrCreateWorkFiles(); // Check tha the work files exist
            Workfolders.CheckOrCreateWorkspaceFolders(); // Check that the work folders exist
            
            btnNewFeed.Enabled = false; // Disabling all buttons - they will become enabled at appropriate times
            btnSaveFeed.Enabled = false;
            btnDelFeed.Enabled = false;
            btnNewCat.Enabled = false;
            btnSaveCat.Enabled = false;
            btnDelCat.Enabled = false;
            
            // New ELL Populate
            EntityLogicLayer.GetPersistentFeedListFromSaveFile(); // !Disk Operation! Load the FeedFile.txt into the persistent Feed variable
            List<ListViewItem> persistentFeed = EntityLogicLayer.SetPersistentFeedListToLvMain(); // Get the persistent Feed variable as a List<ListViewItem>
            Populate.updateListView(lvMain, persistentFeed); // Loop through all the items in the List<ListViewItem>, and then adds them to the ListView lvMain

            lvMain.FullRowSelect = true; // Make the selector cover the full row

            // FIX ALL BELOW TO WORK PROPERLY WITH HOLDING VARIABLES RATHER THAN CONSTANT DISK OPERATIONS!
            string[] listOfGenres = Genre.ReadGenres();
            Populate.updateList(lbxGenre, listOfGenres); // Add the list of genres to the list box
            Populate.updateList(cbxGenre, listOfGenres); // Add the list of genres to the combo box
            cbxGenre.Items.RemoveAt(0); // Remove "All Genres" from the combo box
            string[] listOfFrequencies = Frequencies.ReadFrequencies();
            Populate.updateList(cbxUpFreq, listOfFrequencies); // Add the list of frequencies to the combo box

            try {
                Task asyncUpdate = new Task(() => {
                    EntityLogicLayer.CheckForUpdates(); // Checks if there are updates for the RSS feeds. If there are, it removes the current saved XML file and fetches a new one, updating everything accordingly.
                    EntityLogicLayer.SetPersistentFeedListToLvMain(); // Update lvMain (episode count)
                    EntityLogicLayer.SetPersistentFeedListToSaveFile(); // Update the FeedFile.txt (episode count)
                });
                asyncUpdate.Start();
            } catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }

        // Onclick Event(s)
        private void btnNewCat_Click(object sender, EventArgs e) {
            Genre.AddGenre(txtPoseidon.Text); // Add the genre that is in the text field to the list box
            var listOfGenres = Genre.ReadGenres();
            Populate.updateList(lbxGenre, listOfGenres); // Update the contents of the list box
            Populate.updateList(cbxGenre, listOfGenres); // Update the contents of the combo box
            cbxGenre.Items.RemoveAt(0); // Remove the "All Genres" genre from the combo box
            txtPoseidon.Clear(); // Clear the input field
            txtPoseidon.Focus(); // Return focus to the input field
        }

        private void btnNewFeed_Click(object sender, EventArgs e) {
            // Adds a new feed to the ListView by calling the addNewFeed with the list to which the feed 
            // should be added and another method, which returns a ListViewItem with information pulled
            // from the xml-file the url points to.
            if (txtUrl.Text != null && cbxUpFreq.SelectedItem != null && cbxGenre.SelectedItem != null) {
                if (Validation.IsValidURL(txtUrl.Text)) {
                    try {
                        cts.CancelAfter(2500); // Time out (terminate) async operation if it has not completed after 2.5 seconds
                        Task asyncAddingFeed = new Task(() => AddingFeedLVIToListView(cts)); // I MUST make this a new method to be able to pass in a parameter.
                        asyncAddingFeed.Start();
                    } catch (OperationCanceledException) {
                        MessageBox.Show("The web request to add a new feed timed out! (Exceeded 2.5 second response time)");
                    } catch (Exception ex) {
                        MessageBox.Show(ex.Message);
                    }
                } else {
                    MessageBox.Show("Make sure that the URL is correct!");
                }
            } else {
                MessageBox.Show("Make sure you have filled out all fields!");
            }
            Populate.refreshSelection(lbxGenre);
        }
        private void AddingFeedLVIToListView(CancellationTokenSource ct) {
            string feedURL = txtUrl.Text;
            string updateFrequency = cbxUpFreq.SelectedItem.ToString();
            string genre = cbxGenre.SelectedItem.ToString();
            EntityLogicLayer.GenerateNewFeed(feedURL, updateFrequency, genre); // New feed in ListViewItem format
            List<ListViewItem> mainView = EntityLogicLayer.SetPersistentFeedListToLvMain(); // Returns new listview for lvMain
            Populate.updateListView(lvMain, mainView); // Add the new ListViewItem to the main ListView
            EntityLogicLayer.SetPersistentFeedListToSaveFile(); // Save the persistent feed variable to the FeedFile
            txtUrl.Clear(); // Clear the textfield where the URL was put in
        }

        private void btnSaveCat_Click(object sender, EventArgs e) {
            if (lbxGenre.SelectedIndex >= 1) { // If category selected is index 1 or higher
                lbxGenre.Items[lbxGenre.SelectedIndex] = txtPoseidon.Text; // Set the currently selected index to match the text field txtPoseidon
            }
            Workfiles.ClearFile(Genre.GetGenrePath()); // Clear the genre file
            Populate.updateList(cbxGenre, Genre.UpdateGenreFile(lbxGenre)); // Update the list box and re-write the genre file to match the new content in the list box
            cbxGenre.Items.RemoveAt(0); // Remove the "All Genres" genre from the combo box
        }

        private void btnSaveFeed_Click(object sender, EventArgs e) {
            int selectedIndex = lvMain.SelectedItems[0].Index;
            EntityLogicLayer.UpdateItemFrequencyFromPersistent(selectedIndex, cbxUpFreq.Text);
            EntityLogicLayer.UpdateItemGenreFromPersistent(selectedIndex, cbxGenre.Text);
            List<ListViewItem> mainList = EntityLogicLayer.SetPersistentFeedListToLvMain(); // Take a snapshot of lvMain and put it into the persistent feed variable
            Populate.updateListView(lvMain, mainList);
            EntityLogicLayer.SetPersistentFeedListToSaveFile(); // Save the persistent feed variable to the FeedFile
            // Populate.refreshSelection(lbxGenre);
        }

        private void btnDelCat_Click(object sender, EventArgs e) {
            if (lbxGenre.SelectedIndex >= 1) { // If category selected is index 1 or higher
                Genre.DeleteGenre(lbxGenre); // Delete the genre from the list box
                Workfiles.ClearFile(Genre.GetGenrePath()); // Clear the genre file
                Populate.updateList(cbxGenre, Genre.UpdateGenreFile(lbxGenre)); // Update the list box and re-write the genre file to match the new content in the list box
                cbxGenre.Items.RemoveAt(0); // Remove the "All Genres" genre from the combo box
            } else {
                txtPoseidon.Clear(); // Clear the input field
            }
        }

        private void btnDelFeed_Click(object sender, EventArgs e) {
            EntityLogicLayer.DeleteFeedItemFromPersistent(lvMain.SelectedItems[0].Index);
            List<ListViewItem> mainList = EntityLogicLayer.SetPersistentFeedListToLvMain();
            Populate.updateListView(lvMain, mainList);
            EntityLogicLayer.SetPersistentFeedListToSaveFile();
        }
        // Selection-changed Event(s)
        private void lvlMain_ItemSelectionChanged(object sender, ListViewItemSelectionChangedEventArgs e) {
            if (lvMain.SelectedItems.Count == 1) {
                string url = lvMain.SelectedItems[0].SubItems[4].Text; // Get the URL from the selected list view item
                string feedTitle = lvMain.SelectedItems[0].SubItems[1].Text; // Get the feed title from the selected list view item
                Populate.updateList(lbxEpidsodes, EntityLogicLayer.GetEpisodesFromPersistent(lvMain.SelectedItems[0].Index)); // Update the Episodes list box for the currently selected list view item, and load the episodes into the list
                lblFeedTitle.Text = feedTitle; // Set the label to the feed title
                txtUrl.Text = url; // Set the input field to match the newly selected item's URL
                cbxUpFreq.SelectedItem = lvMain.SelectedItems[0].SubItems[2].Text; // Set the selected item in the combo box to match the currently selected item in the list view
                cbxGenre.SelectedItem = lvMain.SelectedItems[0].SubItems[3].Text; // Set the selected item in the combo box to match the currently selected item in the list view

                btnSaveFeed.Enabled = true;
                btnDelFeed.Enabled = true;
                btnNewFeed.Enabled = false;
                txtUrl.Enabled = false;
            } else {
                lbxEpidsodes.Items.Clear(); // Clear the episodes window if nothing is selected in lvMain
                txtDescription.Clear(); // Clear the description window if nothing is selected in lvMain
                btnSaveFeed.Enabled = false;
                btnDelFeed.Enabled = false;
                txtUrl.Enabled = true;
            }
        }

        private void lbxGenre_SelectedIndexChanged(object sender, EventArgs e) {
            // It is important that the text-field modifiers come before the button state modifiers. This is because there are listeners who change the button states upon text-change. This means that if you change the buttons first, and then the text, the listeners will fire and modify the button states to what they say they should be rather than what you want it to be here.
            if (lbxGenre.SelectedIndex >= 1) {
                txtPoseidon.Text = lbxGenre.SelectedItem.ToString();
                btnNewCat.Enabled = false;
                btnSaveCat.Enabled = true;
                btnDelCat.Enabled = true;
                btnSaveFeed.Enabled = false;
            } else if (lbxGenre.SelectedIndex == 0) {
                txtPoseidon.Clear(); // To not allow people to modify the first entry ("All genres").
                btnNewCat.Enabled = false;
                btnSaveCat.Enabled = false;
                btnDelCat.Enabled = false;
                btnSaveFeed.Enabled = true;
            } else {
                txtPoseidon.Clear();
                btnNewCat.Enabled = true;
                btnSaveCat.Enabled = false;
                btnDelCat.Enabled = false;
            }

            List<ListViewItem> feedsByGenre = Genre.FilterFeedByGenre(lbxGenre, lvMain);
            Populate.updateListView(lvMain, feedsByGenre);
        }

        private void lbxEpisodes_SelectedIndexChanged(object sender, EventArgs e) {
            if (lvMain.SelectedItems.Count == 1) {
                // Gets the description of the specific episode selected in the listbox Episodes from the specific feed selected in the listview lvMain, and populates the appropriate textbox with it
                int episodeIndex = lbxEpidsodes.SelectedIndex; // Currently selected index
                int feedIndex = lvMain.SelectedItems[0].Index;
                string description = EntityLogicLayer.GetEpisodeDescriptionFromPersistent(feedIndex, episodeIndex);
                Populate.updateList(txtDescription, description); // Update the text box txtDescription
            }
        }

        // KeyDown/KeyUp/KeyPress Event(s)
        private void txtUrl_TextChanged(object sender, EventArgs e) {
            btnNewFeed.Enabled = string.IsNullOrWhiteSpace(txtUrl.Text) ? false : true;
        }

        private void txtPoseidon_TextChanged(object sender, EventArgs e) {
            btnNewCat.Enabled = string.IsNullOrWhiteSpace(txtPoseidon.Text) ? false : true;
        }
    }
}