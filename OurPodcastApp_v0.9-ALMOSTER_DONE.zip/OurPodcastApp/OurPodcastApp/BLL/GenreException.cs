﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OurPodcastApp {
    class GenreException : Exception {
        public GenreException() : base("Serialization failed!") {

        }

        public GenreException(string message) : base(message) {

        }
    }
}
