﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OurPodcastApp {
    public class Entity {
        public virtual string EntityType() {
            return "This is a generic entity.";
        }
    }
}
