﻿using System.Collections.Generic;

namespace OurPodcastApp {
    public class Episode : Entity, ITitleable {
        public string Title { get; set; } // Why the fuck do we have to implement a virtual if we have no need for it?!
        public string Description { get; set; }

        public override string EntityType() {
            return "This is an episode.";
        }
    }

    public class EpisodeList : List<Episode> {
        public EpisodeList() {
            // Constructors'R'Us
        }
    }
}