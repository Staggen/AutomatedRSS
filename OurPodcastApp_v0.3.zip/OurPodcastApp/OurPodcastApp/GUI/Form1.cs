﻿using System;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OurPodcastApp {
    public partial class Form1 : Form {
        // Constructor
        public Form1() {
            InitializeComponent();
        }
        // Accessor method for listviews
        public static ListView GetListView(ListView listview) {
            return listview;
        }
        // Form_Load
        private void Form1_Load(object sender, EventArgs e) {
            // Runs on form load
            GetListView(lvMain);
            Workfolders.CheckOrCreateWorkspaceFolders();
            Workfiles.CheckOrCreateWorkFiles();

            btnNewFeed.Enabled = false;
            btnSaveFeed.Enabled = false;
            btnDelFeed.Enabled = false;
            var listItems = Serializer.DeserializeList(Serializer.Deserialize(
                Workfiles.GetFile(Workfiles.Files.FeedFile)));
            foreach (var item in listItems) {
                Population.addNewFeed(lvMain, item);
            }
            lvMain.FullRowSelect = true;

            var listOfGenres = Genre.ReadGenres();
            Population.updateList(lbxGenre, listOfGenres);
            Population.updateList(cbxGenre, listOfGenres);
            cbxGenre.Items.RemoveAt(0);
            var listOfFrequencies = Frequencies.ReadFrequencies();
            Population.updateList(cbxUpFreq, listOfFrequencies);
        }
        // Onclick Event(s)
        private void btnNewCat_Click(object sender, EventArgs e) {
            string newGenre = txtPoseidon.Text;
            Genre.AddGenre(newGenre);
            var listOfGenres = Genre.ReadGenres();
            Population.updateList(lbxGenre, listOfGenres);
            Population.updateList(cbxGenre, listOfGenres);
            cbxGenre.Items.RemoveAt(0);
            txtPoseidon.Clear();
            txtPoseidon.Focus();
        }

        private void btnNewFeed_Click(object sender, EventArgs e) {
            // Adds a new feed to the ListView by calling the addNewFeed with the list to which the feed 
            // should be added and another method, which returns a ListViewItem with information pulled
            // from the xml-file the url points to.
            var newFeed = Feed.GenerateNewFeed(txtUrl.Text, cbxUpFreq.SelectedItem.ToString(),
                cbxGenre.SelectedItem.ToString());
            var listFiller = new ListViewItem(newFeed);
            Population.addNewFeed(lvMain, listFiller);

            string serializedFeed = Serializer.SerializeList(newFeed);
            Serializer.Serialize(Workfiles.GetFile(Workfiles.Files.FeedFile), serializedFeed);
            txtUrl.Clear();
        }

        private void btnSaveCat_Click(object sender, EventArgs e) {
            if (!Validation.IsFirstIndex(lbxGenre)) {
                lbxGenre.Items[lbxGenre.SelectedIndex] = txtPoseidon.Text;
            }
            Workfiles.ClearFile(Genre.GetGenrePath());
            Population.updateList(cbxGenre, Genre.UpdateGenreFile(lbxGenre));
        }

        private void btnSaveFeed_Click(object sender, EventArgs e) {
            Feed.UpdateFeedItemFreq(lvMain, cbxUpFreq.Text);
            Feed.UpdateFeedItemGenre(lvMain, cbxGenre.Text);
            Workfiles.ClearFile(Workfiles.GetFile(Workfiles.Files.FeedFile));
            Feed.UpdateFeedFile(lvMain);
        }

        private void btnDelCat_Click(object sender, EventArgs e) {
            if (!Validation.IsFirstIndex(lbxGenre)) {
                Genre.DeleteGenre(lbxGenre);
                Workfiles.ClearFile(Genre.GetGenrePath());
                Population.updateList(cbxGenre, Genre.UpdateGenreFile(lbxGenre));
            } else {
                txtPoseidon.Clear();
            }
        }

        private void btnDelFeed_Click(object sender, EventArgs e) {
            Feed.DeleteFeedItem(lvMain);
            Workfiles.ClearFile(Workfiles.GetFile(Workfiles.Files.FeedFile));
            Feed.UpdateFeedFile(lvMain);
        }
        // Selection-changed Event(s)
        private async void lvlMain_ItemSelectionChanged(object sender, ListViewItemSelectionChangedEventArgs e) {
            string url = "";
            if (lvMain.SelectedItems.Count > 0) {
                await Task.Run(() => {
                    url = lvMain.SelectedItems[0].SubItems[4].Text;
                    Population.updateList(lbxEpidsodes, Feed.GetEpisodes(url));
                    lblFeedTitle.Text = Feed.GetFeedTitle(url);
                    txtUrl.Text = url;
                    cbxUpFreq.SelectedItem = lvMain.SelectedItems[0].SubItems[2].Text;
                    cbxGenre.SelectedItem = lvMain.SelectedItems[0].SubItems[3].Text;
                    btnSaveFeed.Enabled = true;
                    btnDelFeed.Enabled = true;
                    txtUrl.Enabled = false;
                });
            } else {
                txtUrl.Enabled = true;
            }
        }

        private void lbxGenre_SelectedIndexChanged(object sender, EventArgs e) {
            if (!Validation.IsFirstIndex(lbxGenre)) {
                if (lbxGenre.SelectedItem != null) {
                    txtPoseidon.Text = lbxGenre.SelectedItem.ToString();
                }
            } else {
                txtPoseidon.Clear();
            }
        }

        private async void lbxEpisodes_SelectedIndexChanged(object sender, EventArgs e) {
            if (lvMain.SelectedItems.Count > 0) {
                await Task.Run(() => {
                    string url = lvMain.SelectedItems[0].SubItems[4].Text;
                    int.TryParse(lvMain.SelectedItems[0].SubItems[0].Text, out int epCount);
                    int selIndex = lbxEpidsodes.SelectedIndex;
                    string content = Feed.GetEpisodeDescriptions(url, epCount, selIndex);
                    Population.updateList(txtDescription, content);
                });
            }
        }
        // KeyDown/KeyUp/KeyPress Event(s)
        private void txtUrl_TextChanged(object sender, EventArgs e) {
            btnNewFeed.Enabled = string.IsNullOrEmpty(txtUrl.Text) ? false : true
                || string.IsNullOrWhiteSpace(txtUrl.Text) ? false : true;
        }
    }
}