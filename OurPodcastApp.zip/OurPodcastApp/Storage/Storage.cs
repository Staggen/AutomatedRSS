﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Collections;
using System.Net;
using System.Xml;
using System.Windows.Forms;

namespace OurPodcastApp {
    class Storage {

        public static string[] WorkFolders = {
            @"TeamN2037\",
            @"TeamN2037\Archive\",
            @"TeamN2037\Temp\",
            @"TeamN2037\SavePodData\"
        };

        public static string[] WorkFiles = {
            @"TeamN2037\Config.txt",
            @"TeamN2037\feedfile.txt",
            @"TeamN2037\genres.txt",
            @"TeamN2037\updfreq.txt",
        };        

        public enum Folders {
            TeamN2037,
            Archived,
            Temp,
            SavePodData
        }

        public enum Files {
            ConfigFile,
            FeedFile,
            GenreFile,
            FreqFile
        }

        public static void CheckOrCreateWorkFiles() {
            var total = WorkFiles.Length;
            string conclusion = "";
            for (int i = 0; i < total; i++) {
                var fileName = GetFile((Files)i);
                var fileEnum = ((Files)i);
                if (!Validation.IsFileWritten(fileName)) {
                    switch (fileEnum) {
                        case Files.ConfigFile:
                            CreateConfig();
                            break;
                        case Files.FeedFile:
                            File.Create(fileName);
                            //Feed.UpdateFeedFile();
                            break;
                        case Files.GenreFile:
                            Genre.CreateGenres();
                            break;
                        case Files.FreqFile:
                            Frequencies.CreateFreqs();
                            break;
                    }
                    conclusion += "Created and loaded the file '" + fileName + "'\n";
                } else {
                    conclusion += "The file '" + fileName + "' loaded correctly.\n";
                }
            }
            MessageBox.Show(conclusion);
        }

        public static void CreateConfig() {
            string filePath = GetFile(Files.ConfigFile);
            if (!File.Exists(filePath)) {
                Serializer.Serialize(filePath, WorkFolders);
            }
        }

        public static void CheckOrCreateWorkspaceFolders() {
            var total = WorkFolders.Length;
            string conclusion = "";
            for (int i = 0; i < total; i++) {
                var dirName = GetFolder((Folders)i);
                var folderEnum = ((Folders)i);
                if (!Validation.IsDirectory(dirName)) {
                    switch (folderEnum) {
                        case Folders.TeamN2037:
                            Directory.CreateDirectory(dirName);
                            CreateConfig();
                            break;
                        case Folders.Archived:
                            Directory.CreateDirectory(dirName);
                            break;
                        case Folders.Temp:
                            Directory.CreateDirectory(dirName);
                            break;
                        case Folders.SavePodData:
                            Directory.CreateDirectory(dirName);
                            break;
                    }
                    conclusion += "Created and loaded the directory '" + dirName + "'\n";
                } else {
                    conclusion += "The directory '" + dirName + "' loaded correctly.\n";
                }
            }
            MessageBox.Show(conclusion);            
        }

        internal static void SaveFeedLocally(string url) {
            var tempfilepath = GetFolder(Folders.Temp) + "temp_feed.xml";
            string rssFeed = "";
            using (var client = new WebClient()) {
                client.Encoding = Encoding.UTF8;
                rssFeed = client.DownloadString(url);
            }
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;
            settings.IndentChars = "\t";
            using (var stream = new FileStream(tempfilepath, FileMode.Append, FileAccess.Write)) {
                using (var writer = XmlWriter.Create(stream)) {
                    writer.WriteRaw(rssFeed);
                    writer.Close();
                }
            }
        }

        //public static string GetMainFeedFile() {
        //    return GetFolderByName(Folders.TeamN2037) + 
        //}

        //public static void CreateConfig() {
        //    foreach (var filepath in WorkFiles) {
        //        if (!File.Exists(filepath)) {
        //            File.WriteAllLines(filepath, WorkFiles);
        //        }
        //    }
        //    if (!File.Exists(configFile)) {
        //        File.WriteAllLines(configFile, WorkFolders);
        //    }
        //}

        public static void CreateOrWriteLvFile(string filePath, string[] content) {
            if (!File.Exists(filePath)) {
                using (var stream = new FileStream(filePath, FileMode.Append, FileAccess.Write)) {
                    using (var writer = new StreamWriter(stream)) {
                        File.WriteAllLines(filePath, content);
                    }
                }
            }
        }

        //public static string[] ReadFile(string filePath) {
        //    ArrayList lvList = new ArrayList();
        //    using (var stream = new FileStream(filePath,
        //        FileMode.Open,
        //        FileAccess.Read)) {
        //        using (var reader = new StreamReader(stream)) {
        //            while (reader.Peek() != -1) {
        //                lvList.Add(reader.ReadLine());
        //            }
        //        }
        //        return (string[])lvList.ToArray();
        //    }
        //}

        public static void ClearFile(string filePath) {
            using (var stream = new FileStream(filePath, FileMode.Truncate, FileAccess.Write)) {
                //this makes the opened file contain 0 bytes of data, i.e nothing, clearing the file.
            }
        }

        public static string GetFile(Files name) {
            return WorkFiles[(int)name];
        }


        //public static void ReadConfig() {
        //    var lines = File.ReadAllLines(configFile);
        //    var total = lines.Length;
        //    Array.Resize(ref WorkFolders, total);
        //    for (int i = 0; i < total; i++) {
        //        var pathString = lines[i];
        //        Console.WriteLine("Setting path - " + pathString);
        //        WorkFolders[i] = pathString;
        //    }
        //}
        public static string GetFolder(Folders name) {
            return WorkFolders[(int)name];
        }

        public static void ArchiveWorkFiles() {
            var allWorkFiles = Directory.GetFiles(GetFolder(Folders.TeamN2037));
            foreach (var path in allWorkFiles) {
                var fileName = Path.GetFileName(path);
                var tmpPath = GetFolder(Folders.Temp) + fileName;
                var archivePath = GetFolder(Folders.Archived) + fileName;         
                File.Copy(path, tmpPath);
                string[] tmpDocLines = File.ReadAllLines(path);
                string docString = String.Join(Environment.NewLine, tmpDocLines);
                var workspaceDirName = Path.GetDirectoryName(GetFolder(Folders.TeamN2037));
                var newWorkspaceDirName = workspaceDirName + DateTime.Now.ToString("yyyyMMddHHmmss");
                docString = docString.Replace(workspaceDirName, newWorkspaceDirName);
                File.WriteAllText(tmpPath, docString);
                File.Move(tmpPath, archivePath);
            }
        }

        //public static void ArchiveConfig() {
        //    var configPath = configFile;
        //    var configName = Path.GetFileName(configPath);
        //    var tmpPath = GetFolder(Folders.Temp) + configName;
        //    var newPath = GetFolder(Folders.SavePodData) + configName;
        //    File.Copy(configPath, tmpPath);
        //    var lines = File.ReadAllLines(tmpPath);
        //    var configString = String.Join(Environment.NewLine, lines);
        //    var workspaceDirName = Path.GetDirectoryName(GetFolder(Folders.TeamN2037));
        //    var newWorkspaceDirName = workspaceDirName + DateTime.Now.ToString("yyyyMMddHHmmss");
        //    configString = configString.Replace(workspaceDirName, newWorkspaceDirName);
        //    File.WriteAllText(tmpPath, configString);
        //    File.Move(tmpPath, newPath);
        //}

        public void CopySaveData() {
            var saveDataDir = GetFolder(Folders.SavePodData);
            if (Directory.Exists(saveDataDir)) {
                var destDirName = GetFolder(Folders.Archived);
                destDirName += Path.GetFileName(saveDataDir.Trim(Path.DirectorySeparatorChar));
                destDirName += "_" + DateTime.Now.ToString("yyyyMMddHHmmss");
                Directory.Move(saveDataDir, destDirName);
            }
        }
    }
}