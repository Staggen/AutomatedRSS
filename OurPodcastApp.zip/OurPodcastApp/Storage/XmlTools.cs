﻿using System.ServiceModel.Syndication;
using System.Xml;

namespace OurPodcastApp {
    public class XmlTools {
        public static SyndicationFeed CreateSyndicationFeed(string url) {
            using (XmlReader reader = XmlReader.Create(url)) {
                SyndicationFeed feed = SyndicationFeed.Load(reader);
                return feed;
            }
        }

        public static XmlReader CreateXmlReader(string url) {
            XmlReader reader = XmlReader.Create(url);
            return reader;
        }
    }
}