﻿using System.Collections.Generic;

namespace OurPodcastApp {
    public class Episode : ITitleicious {
        public string Title { get; set; }
        public string Description { get; set; }
    }

    public class EpisodeList : List<Episode> {
        public EpisodeList() {
            // Constructors'R'Us
        }
    }
}