﻿using System.Collections.Generic;
using System.Windows.Forms;

namespace OurPodcastApp {
    public class Feed : ITitleicious {

        public string Title { get; set; }
        public int EpisodeCount { get; set; }
        public string UpdateFrequency { get; set; }
        public string Genre { get; set; }

        public static string feedPath = Storage.GetFile(Storage.Files.FeedFile);

        public static string[] GenerateNewFeed(string feedUrl, string updateFreq, string genre) {
            string feedTitle = "";
            EpisodeList episodeList = new EpisodeList();
            var feed = XmlTools.CreateSyndicationFeed(feedUrl);
            feedTitle = feed.Title.Text;
            foreach (var item in feed.Items) {
                episodeList.Add(new Episode { Title = item.Title.Text });
                Storage.SaveFeedLocally(feedUrl);
            }
            return new string[] { episodeList.Count.ToString(), feedTitle, updateFreq, genre, feedUrl };
        }

        public static void DeleteFeedItem(ListView lv) {
            foreach (ListViewItem item in lv.SelectedItems) {
                lv.Items.Remove(item);
            }
        }

        public static void UpdateFeedItemFreq(ListView lv, string newValue) {
            lv.SelectedItems[0].SubItems[2].Text = newValue;
        }

        public static void UpdateFeedItemGenre(ListView lv, string newValue) {
            lv.SelectedItems[0].SubItems[3].Text = newValue;
        }

        public static void UpdateFeedFile(ListView lv) {
            var feedPath = Storage.GetFile(Storage.Files.FeedFile);
            ListViewItem[] currentFeeds = new ListViewItem[lv.Items.Count];
            lv.Items.CopyTo(currentFeeds, 0);            
            foreach (var item in currentFeeds) {
                var tempList = new string[5];
                tempList[0] = item.SubItems[0].Text;
                tempList[1] = item.SubItems[1].Text;
                tempList[2] = item.SubItems[2].Text;
                tempList[3] = item.SubItems[3].Text;
                tempList[4] = item.SubItems[4].Text;
                Serializer.Serialize(feedPath, Serializer.SerializeList(tempList));
            }
        }

        public static EpisodeList GetEpisodes(string feedUrl) {
            EpisodeList episodeList = new EpisodeList();
            var feed = XmlTools.CreateSyndicationFeed(feedUrl);
            foreach (var item in feed.Items) {
                episodeList.Add(new Episode { Title = item.Title.Text });
            }
            return episodeList;
        }        

        public static string GetFeedTitle(string feedUrl) {
            EpisodeList episodeList = new EpisodeList();
            var feed = XmlTools.CreateSyndicationFeed(feedUrl);
            var feedTitle = feed.Title.Text;
            return feedTitle;
        }

        public static string GetEpisodeDescriptions(string feedUrl, int epCount, int selIndex) {
            var reader = XmlTools.CreateXmlReader(feedUrl);
            string[] epiDescList = new string[epCount];
            for (int i = 0; i < epCount; i++) {
                reader.ReadToFollowing("content:encoded");
                epiDescList[i] = reader.ReadInnerXml() ;
            }
            return epiDescList[selIndex];
        }

        public class FeedList : List<Feed> {

        }
    }
}