﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace OurPodcastApp {
    
    public class Frequencies {
        public static string FreqPath = Storage.GetFile(Storage.Files.FreqFile);

        //public static void CheckFreqFile() {
        //    if (!Validation.IsFileWritten(FreqPath)) {
        //        CreateFreqs();
        //    }
        //}
        public static string[] freqList = {
            "Ten min",
            "One hour",
            "One day",
            "One week",
            "One month"
        };

        public enum Frequency {
            min,
            hr,
            day,
            week,
            month,
        }

        public static string GetFreq(Frequency name) {
            return freqList[(int)name];
        }

        public static void CreateFreqs() {
            if (!File.Exists(FreqPath)) {
                Serializer.Serialize(FreqPath, freqList);
            } else {
                Storage.ClearFile(FreqPath);
                Serializer.Serialize(FreqPath, freqList);
            }
        }

        public static string[] ReadFrequencies() {
            return Serializer.Deserialize(FreqPath);
        }
        
    }
}
