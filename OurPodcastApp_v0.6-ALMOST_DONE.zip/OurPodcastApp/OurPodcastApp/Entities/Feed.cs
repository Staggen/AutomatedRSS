﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Xml;

namespace OurPodcastApp {
    public class Feed : ITitleicious {
        public string Title { get; set; }
        public int EpisodeCount { get; set; }
        public string UpdateFrequency { get; set; }
        public string Genre { get; set; }

        public static string feedPath = Workfiles.GetFile(Workfiles.Files.FeedFile);

        public static string[] GenerateNewFeed(string feedUrl, string updateFreq, string genre) {
            string feedTitle = "";
            EpisodeList episodeList = new EpisodeList();
            var feed = XmlTools.CreateSyndicationFeed(feedUrl);
            feedTitle = feed.Title.Text;
            foreach (var item in feed.Items) {
                episodeList.Add(new Episode { Title = item.Title.Text });
            }
            XmlTools.SaveFeedToFile(feedUrl, Workfolders.GetFolder(Workfolders.Folders.SavePodData), feedTitle);
            return new string[] { episodeList.Count.ToString(), feedTitle, updateFreq, genre, feedUrl, DateTime.Now.ToUniversalTime().ToString() };
        }

        public static void DeleteFeedItem(ListView lv) {
            foreach (ListViewItem item in lv.SelectedItems) {
                lv.Items.Remove(item);
            }
        }

        public static void UpdateFeedItemFreq(ListView lv, string newValue) {
            lv.SelectedItems[0].SubItems[2].Text = newValue;
        }

        public static void UpdateFeedItemGenre(ListView lv, string newValue) {
            lv.SelectedItems[0].SubItems[3].Text = newValue;
        }

        public static void UpdateFeedFile(ListView lv) {
            var feedPath = Workfiles.GetFile(Workfiles.Files.FeedFile);
            ListViewItem[] currentFeeds = new ListViewItem[lv.Items.Count];
            lv.Items.CopyTo(currentFeeds, 0);
            foreach (var item in currentFeeds) {
                var tempList = new string[item.SubItems.Count];
                for (int i = 0; i < tempList.Length; i++) {
                    tempList[i] = item.SubItems[i].Text;
                }
                Serializer.Serialize(feedPath, Serializer.SerializeList(tempList));
            }
        }

        public static int GetEpisodeCount(string url) {
            return XmlTools.GetEpisodeInfo(url).Count;
        }

        public static void UpdateFeedItemEpCount(Dictionary<int, bool> data, ListView view) {
            foreach (var kvp in data) {
                MessageBox.Show(view.Items[kvp.Key].SubItems[5].Text);
                if (kvp.Value == false) {
                    //Gets a fresh episode count from the url tied to the current feed item.
                    int newEpCount = GetEpisodeCount(view.Items[kvp.Key].SubItems[4].Text);
                    //Updates the episodes count in the list
                    view.Items[kvp.Key].SubItems[0].Text = newEpCount.ToString();
                    //Updates the timestamp to current time
                    view.Items[kvp.Key].SubItems[5].Text = DateTime.Now.ToUniversalTime().ToString();
                }
            }
        }

        public static EpisodeList GetEpisodes(string feedUrl) {
            EpisodeList episodeList = new EpisodeList();
            var testing = XmlTools.GetEpisodeInfo(Workfolders.GetFolder(Workfolders.Folders.SavePodData)+"Never Not Funny The Jimmy Pardo Podcast.xml");
            int numberOfEpisodes = GetEpisodeCount(feedUrl); // (?)
            // TURN ON TEXT-WRAP IF YOU HAVE NOT ALREADY DONE SO! Work with the above rather than the SyndicationFeed below (kill it), and use the passed parameters rather than hard-coding the path to the .xml file. From GetEpisodeInfo(filepath) you will get a dictionary containing the episode titles and descriptions. Then, using that dictionary and a for-loop, make 
            // new Episode { Title = dictionary.Keys[i](?), Description = dictionary.Values[i](?) }
            var feed = XmlTools.CreateSyndicationFeed(feedUrl);
            foreach (var item in feed.Items) {
                episodeList.Add(new Episode { Title = item.Title.Text });
            }
            return episodeList;
        }

        public static string GetFeedTitle(string feedUrl) {
            EpisodeList episodeList = new EpisodeList();
            var feed = XmlTools.CreateSyndicationFeed(feedUrl);
            var feedTitle = feed.Title.Text;
            return feedTitle;
        }

        public static string GetEpisodeDescriptions(string feedUrl, int epCount, int selIndex) {
            var reader = XmlTools.CreateXmlReader(feedUrl);
            string[] epiDescList = new string[epCount];
            for (int i = 0; i < epCount; i++) {
                reader.ReadToFollowing("content:encoded");
                epiDescList[i] = reader.ReadInnerXml();
            }
            return epiDescList[selIndex];
        }

        public class FeedList : List<Feed> {
            FeedList() {
                // Constructors'R'Us
            }
        }
    }
}