﻿using System.Collections.Generic;
using System.ServiceModel.Syndication;
using System.Text.RegularExpressions;
using System.Xml;

namespace OurPodcastApp {
    public class XmlTools {
        public static SyndicationFeed CreateSyndicationFeed(string url) {
            using (XmlReader reader = XmlReader.Create(url)) {
                SyndicationFeed feed = SyndicationFeed.Load(reader);
                return feed;
            }
        }

        public static XmlReader CreateXmlReader(string url) {
            XmlReader reader = XmlReader.Create(url);
            return reader;
        }

        public static XmlWriter CreateXmlWriter(string path) {
            XmlWriter writer = XmlWriter.Create(path);
            return writer;
        }

        public static void SaveFeedToFile(string url, string path, string feedTitle) {
            string legalTitle = Regex.Replace(feedTitle, @"[\/:*|<>?]", "");
            XmlDocument document = new XmlDocument();
            document.Load(url);
            document.Save(path + legalTitle + ".xml");
        }

        public static Dictionary<string, string> GetEpisodeInfo(string path) { // Praise the sun, it works!
            Dictionary<string, string> episodeDictionary = new Dictionary<string, string>(); // Make dictionary
            string fixedDescription;
            XmlDocument document = new XmlDocument(); // Holding variable
            document.Load(path); // Load the XML document into the holding variable
            XmlNodeList titles = document.SelectNodes("//rss/channel/item/title"); // List of XML nodes matching selector
            XmlNodeList descriptions = document.SelectNodes("//rss/channel/item/description"); // -||-
            for (int i = 0; i < titles.Count; i++) { // titles and descriptions SHOULD be equally long
                fixedDescription = Regex.Replace(descriptions[i].InnerText,@"<.*?>",""); // Remove HTML formating
                episodeDictionary.Add(titles[i].InnerText, fixedDescription); // Add titles and descriptions to the dictionary
            }
            return episodeDictionary; // Return dictionary
        }
    }
}