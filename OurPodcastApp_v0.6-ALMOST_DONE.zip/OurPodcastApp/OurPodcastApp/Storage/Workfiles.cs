﻿using System;
using System.Text;
using System.IO;
using System.Net;
using System.Xml;
using System.Windows.Forms;

namespace OurPodcastApp {
    class Workfiles {
        public enum Files {
            ConfigFile,
            FeedFile,
            GenreFile,
            FreqFile
        }

        public static string[] WorkFiles = {
            @"TeamN2037\Config.txt",
            @"TeamN2037\feedfile.txt",
            @"TeamN2037\genres.txt",
            @"TeamN2037\updfreq.txt",
        };

        public static string GetFile(Files name) {
            return WorkFiles[(int)name];
        }

        public static void ClearFile(string filePath) {
            using (var stream = new FileStream(filePath, FileMode.Truncate, FileAccess.Write)) {
                // This makes the opened file contain 0 bytes of data, i.e nothing, effectively clearing the file.
            }
        }

        public static void CheckOrCreateWorkFiles() {
            var total = WorkFiles.Length;
            string conclusion = "";
            for (int i = 0; i < total; i++) {
                var fileName = GetFile((Files)i);
                var fileEnum = ((Files)i);
                if (!Validation.IsFileWritten(fileName)) {
                    switch (fileEnum) {
                        case Files.ConfigFile:
                            CreateConfig();
                            break;
                        case Files.FeedFile:
                            File.Create(fileName);
                            break;
                        case Files.GenreFile:
                            Genre.CreateGenres();
                            break;
                        case Files.FreqFile:
                            Frequencies.CreateFreqs();
                            break;
                    }
                    conclusion += "Created and loaded the file '" + fileName + "'\n";
                } else {
                    conclusion += "The file '" + fileName + "' loaded correctly.\n";
                }
            }
            MessageBox.Show(conclusion);
        }

        public static void CreateOrWriteLvFile(string filePath, string[] content) {
            if (!File.Exists(filePath)) {
                using (var stream = new FileStream(filePath, FileMode.Append, FileAccess.Write)) {
                    using (var writer = new StreamWriter(stream)) {
                        File.WriteAllLines(filePath, content);
                    }
                }
            }
        }

        public static void CreateConfig() {
            string filePath = GetFile(Files.ConfigFile);
            if (!File.Exists(filePath)) {
                Serializer.Serialize(filePath, Workfolders.WorkFolders);
            }
        }

        public static void ArchiveWorkFiles() {
            var allWorkFiles = Directory.GetFiles(Workfolders.GetFolder(Workfolders.Folders.TeamN2037));
            foreach (var path in allWorkFiles) {
                var fileName = Path.GetFileName(path);
                var tmpPath = Workfolders.GetFolder(Workfolders.Folders.Temp) + fileName;
                var archivePath = Workfolders.GetFolder(Workfolders.Folders.Archived) + fileName;
                File.Copy(path, tmpPath);
                string[] tmpDocLines = File.ReadAllLines(path);
                string docString = String.Join(Environment.NewLine, tmpDocLines);
                var workspaceDirName = Path.GetDirectoryName(Workfolders.GetFolder(Workfolders.Folders.TeamN2037));
                var newWorkspaceDirName = workspaceDirName + DateTime.Now.ToString("yyyyMMddHHmmss");
                docString = docString.Replace(workspaceDirName, newWorkspaceDirName);
                File.WriteAllText(tmpPath, docString);
                File.Move(tmpPath, archivePath);
            }
        }
    }
}