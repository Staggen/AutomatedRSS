﻿using System;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OurPodcastApp {
    public partial class Form1 : Form {
        // Cancellation Token Source
        CancellationTokenSource cts = new CancellationTokenSource();
        // Constructor
        public Form1() {
            InitializeComponent();
        }
        // Form_Load
        private void Form1_Load(object sender, EventArgs e) {
            // Runs on form load
            Workfiles.CheckOrCreateWorkFiles();
            Workfolders.CheckOrCreateWorkspaceFolders();

            btnNewFeed.Enabled = false;
            btnSaveFeed.Enabled = false;
            btnDelFeed.Enabled = false;
            btnNewCat.Enabled = false;
            btnSaveCat.Enabled = false;
            btnDelCat.Enabled = false;

            var listItems = Serializer.DeserializeList(Serializer.Deserialize(
                Workfiles.GetFile(Workfiles.Files.FeedFile)));
            foreach (var item in listItems) {
                Population.addNewFeed(lvMain, item);
            }
            lvMain.FullRowSelect = true;

            var listOfGenres = Genre.ReadGenres();
            Population.updateList(lbxGenre, listOfGenres);
            Population.updateList(cbxGenre, listOfGenres);
            cbxGenre.Items.RemoveAt(0);
            var listOfFrequencies = Frequencies.ReadFrequencies();
            Population.updateList(cbxUpFreq, listOfFrequencies);

            // ListLooper returns a List of ListViewItems, which we use to call CheckForUpdates, which
            // returns a Dictionary. Then we use that dictionary as a parameter in UpdateFeed.
            Feed.UpdateFeedItemEpCount(Updater.CheckForUpdates(Updater.ListLooper(lvMain)), lvMain);
            Workfiles.ClearFile(Workfiles.GetFile(Workfiles.Files.FeedFile));
            Feed.UpdateFeedFile(lvMain);
        }
        // Onclick Event(s)
        private void btnNewCat_Click(object sender, EventArgs e) {
            string newGenre = txtPoseidon.Text;
            Genre.AddGenre(newGenre);
            var listOfGenres = Genre.ReadGenres();
            Population.updateList(lbxGenre, listOfGenres);
            Population.updateList(cbxGenre, listOfGenres);
            cbxGenre.Items.RemoveAt(0);
            txtPoseidon.Clear();
            txtPoseidon.Focus();
        }

        private async void btnNewFeed_Click(object sender, EventArgs e) {
            // Adds a new feed to the ListView by calling the addNewFeed with the list to which the feed 
            // should be added and another method, which returns a ListViewItem with information pulled
            // from the xml-file the url points to.
            if (txtUrl.Text != null && cbxUpFreq.SelectedItem != null && cbxGenre.SelectedItem != null) {
                if (Validation.IsValidURL(txtUrl.Text)) {
                    try {
                        cts.CancelAfter(2500);
                        await AddNewFeed(cts); // I MUST make this a new method to be able to pass in a parameter.
                    } catch (OperationCanceledException) {
                        MessageBox.Show("The web request to add a new feed timed out! (Exceeded 2.5 second response time)");
                    } catch (Exception ex) {
                        MessageBox.Show(ex.Message);
                    }
                } else {
                    MessageBox.Show("Make sure that the URL is correct!");
                }
            } else {
                MessageBox.Show("Make sure you have filled out all fields!");
            }
        }
        private async Task AddNewFeed(CancellationTokenSource ct) {
            var newFeed = Feed.GenerateNewFeed(txtUrl.Text, cbxUpFreq.SelectedItem.ToString(), cbxGenre.SelectedItem.ToString());
            var listFiller = new ListViewItem(newFeed);
            Population.addNewFeed(lvMain, listFiller);

            string serializedFeed = Serializer.SerializeList(newFeed);
            Serializer.Serialize(Workfiles.GetFile(Workfiles.Files.FeedFile), serializedFeed);
            txtUrl.Clear();
        }

        private void btnSaveCat_Click(object sender, EventArgs e) {
            if (lbxGenre.SelectedIndex >= 1) {
                lbxGenre.Items[lbxGenre.SelectedIndex] = txtPoseidon.Text;
            }
            Workfiles.ClearFile(Genre.GetGenrePath());
            Population.updateList(cbxGenre, Genre.UpdateGenreFile(lbxGenre));
        }

        private void btnSaveFeed_Click(object sender, EventArgs e) {
            Feed.UpdateFeedItemFreq(lvMain, cbxUpFreq.Text);
            Feed.UpdateFeedItemGenre(lvMain, cbxGenre.Text);
            Workfiles.ClearFile(Workfiles.GetFile(Workfiles.Files.FeedFile));
            Feed.UpdateFeedFile(lvMain);
        }

        private void btnDelCat_Click(object sender, EventArgs e) {
            if (!Validation.IsFirstIndex(lbxGenre)) {
                Genre.DeleteGenre(lbxGenre);
                Workfiles.ClearFile(Genre.GetGenrePath());
                Population.updateList(cbxGenre, Genre.UpdateGenreFile(lbxGenre));
            } else {
                txtPoseidon.Clear();
            }
        }

        private void btnDelFeed_Click(object sender, EventArgs e) {
            Feed.DeleteFeedItem(lvMain);
            Workfiles.ClearFile(Workfiles.GetFile(Workfiles.Files.FeedFile));
            Feed.UpdateFeedFile(lvMain);
        }
        // Selection-changed Event(s)
        private async void lvlMain_ItemSelectionChanged(object sender, ListViewItemSelectionChangedEventArgs e) {
            if (lvMain.SelectedItems.Count > 0) {
                try {
                    cts.CancelAfter(2500);
                    await lvMainChanged(cts);
                } catch (OperationCanceledException) {
                    MessageBox.Show("The web request to select this feed timed out! (Exceeded 2.5 second response time)");
                } catch (Exception ex) {
                    MessageBox.Show(ex.Message);
                }
            } else {
                btnSaveFeed.Enabled = false;
                btnDelFeed.Enabled = false;
                txtUrl.Enabled = true;
            }
        }
        private async Task lvMainChanged(CancellationTokenSource ct) {
            string url = "";
            url = lvMain.SelectedItems[0].SubItems[4].Text;
            Population.updateList(lbxEpidsodes, Feed.GetEpisodes(url));
            lblFeedTitle.Text = Feed.GetFeedTitle(url);
            txtUrl.Text = url;
            cbxUpFreq.SelectedItem = lvMain.SelectedItems[0].SubItems[2].Text;
            cbxGenre.SelectedItem = lvMain.SelectedItems[0].SubItems[3].Text;
            btnSaveFeed.Enabled = true;
            btnDelFeed.Enabled = true;
            txtUrl.Enabled = false;
        }

        private void lbxGenre_SelectedIndexChanged(object sender, EventArgs e) {
            // It is important that the text-field modifiers come before the button state modifiers.
            // This is because there are listeners who change the button states upon text-change.
            // This means that if you change the buttons first, and then the text, the listeners will fire
            // and modify the button states to what they say they should be rather than what you want it to
            // be here.
            if (lbxGenre.SelectedIndex >= 1) {
                txtPoseidon.Text = lbxGenre.SelectedItem.ToString();
                btnNewCat.Enabled = false;
                btnSaveCat.Enabled = true;
                btnDelCat.Enabled = true;
            } else if (lbxGenre.SelectedIndex == 0) {
                txtPoseidon.Clear(); // To not allow people to modify the first entry ("All genres").
                btnNewCat.Enabled = false;
                btnSaveCat.Enabled = false;
                btnDelCat.Enabled = false;
            } else {
                txtPoseidon.Clear();
                btnNewCat.Enabled = true;
                btnSaveCat.Enabled = false;
                btnDelCat.Enabled = false;
            }
        }

        private async void lbxEpisodes_SelectedIndexChanged(object sender, EventArgs e) {
            if (lvMain.SelectedItems.Count > 0) {
                try {
                    cts.CancelAfter(2500);
                    await lbxEpisodeChanged(cts);
                } catch (OperationCanceledException) {
                    MessageBox.Show("The web request to select this episode timed out! (Exceeded 2.5 second response time)");
                } catch (Exception ex) {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        private async Task lbxEpisodeChanged(CancellationTokenSource ct) {
            string url = lvMain.SelectedItems[0].SubItems[4].Text;
            int.TryParse(lvMain.SelectedItems[0].SubItems[0].Text, out int epCount);
            int selIndex = lbxEpidsodes.SelectedIndex;
            string content = Feed.GetEpisodeDescriptions(url, epCount, selIndex);
            Population.updateList(txtDescription, content);
        }
        // KeyDown/KeyUp/KeyPress Event(s)
        private void txtUrl_TextChanged(object sender, EventArgs e) {
            btnNewFeed.Enabled = string.IsNullOrWhiteSpace(txtUrl.Text) ? false : true;
        }

        private void txtPoseidon_TextChanged(object sender, EventArgs e) {
            btnNewCat.Enabled = string.IsNullOrWhiteSpace(txtPoseidon.Text) ? false : true;
        }
    }
}