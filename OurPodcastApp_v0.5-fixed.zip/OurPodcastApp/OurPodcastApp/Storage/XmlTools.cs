﻿using System.IO;
using System.ServiceModel.Syndication;
using System.Text.RegularExpressions;
using System.Xml;

namespace OurPodcastApp {
    public class XmlTools {
        public static SyndicationFeed CreateSyndicationFeed(string url) {
            using (XmlReader reader = XmlReader.Create(url)) {
                SyndicationFeed feed = SyndicationFeed.Load(reader);
                return feed;
            }
        }

        public static XmlReader CreateXmlReader(string url) {
            XmlReader reader = XmlReader.Create(url);
            return reader;
        }

        public static XmlWriter CreateXmlWriter(string path) {
            XmlWriter writer = XmlWriter.Create(path);
            return writer;
        }

        public static void SaveFeedToFile(string url, string path, string feedTitle) {
            string legalTitle = Regex.Replace(feedTitle, @"[\/:*|<>?]", "");
            XmlDocument document = new XmlDocument();
            document.Load(url);
            document.Save(path + legalTitle + ".xml");
        }
    }
}
